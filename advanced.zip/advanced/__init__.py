# Advanced Order Types Package
"""
Advanced order types for Binance Futures Trading Bot.
Includes Stop-Limit, OCO, TWAP, and Grid trading strategies.
"""

__version__ = "1.0.0"